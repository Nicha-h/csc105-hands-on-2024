import { Cart } from './component/Cart.jsx';
import './App.css'

const App = () => {
  return (  
    <div className="Home">
      <div className="Container">
          <Cart />
      </div>
    </div>
  );
}

export default App;